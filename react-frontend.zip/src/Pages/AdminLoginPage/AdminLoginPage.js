import "./AdminLoginPage.css";
import { Link } from "react-router-dom";

const AdminLoginPage = () => {
  return (
    <div className="login-page-section">
      <header className="header">
        <nav>
          <ul>
            <li>
              <Link to="/admin">Pharmacy Management System Admin</Link>
            </li>
            <li>
              <Link to="/">Home</Link>
            </li>
          </ul>
        </nav>
      </header>
      <div className="login-page-container">
        <form>
          <label className="title-login">Admin Account</label>

          <div className="credentials-section">
            <label>Email Address</label>
            <input
              placeholder="Enter your Email Address"
              type="email"
              name="email"
            />
          </div>

          <div className="credentials-section">
            <label>Password</label>
            <input
              placeholder="Enter your Password"
              type="password"
              name="password"
            />
          </div>

          <button className="login-button">Login</button>
        </form>
      </div>
    </div>
  );
};

export default AdminLoginPage;
