import DefaultNavbar from "../../Components/DefaultNavbar/DefaultNavbar";
import "./LoginPage.css";
import { Link } from "react-router-dom";



const LoginPage = () => {
    return (
        <div className="login-page-section">
            <DefaultNavbar/>
            <div className="login-page-container">
            <form>
                <label className="title-login">Login your Account</label>

                <div className="credentials-section">
                    <label>Email Address</label>
                    <input placeholder="Enter your Email Address" type="email" name="email" />
                </div>

                <div className="credentials-section">
                    <label>Password</label>
                    <input placeholder="Enter your Password" type="password" name="password" />
                </div>
                
                <p className="no-ac">No Account yet ? <Link to="/register">Register Now</Link></p>

                <button className="login-button">Login</button>
            </form>
            </div>
        </div>
    )
}


export default LoginPage