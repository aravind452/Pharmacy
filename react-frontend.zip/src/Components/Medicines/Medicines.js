import { useState } from "react";
import "./Medicines.css";

function Medicines(props) {
  const [cartProducts, setCartProducts] = useState([]);

  function handleAddProduct(product_id) {
    let cartProduct = [];
    cartProduct = [...cartProducts, product_id];
    setCartProducts(cartProduct);
  }

  console.log(cartProducts);

  return (
    <div className="medi-card">
      <h1>
        Name: <span>{props.products.product_name}</span>
      </h1>
      <h2>
        Amount: <span>$</span>
        {props.products.product_price}
      </h2>
      <button
        onClick={() => {
          handleAddProduct(props.products.product_id);
        }}
      >
        Add to Cart
      </button>
    </div>
  );
}

export default Medicines;
