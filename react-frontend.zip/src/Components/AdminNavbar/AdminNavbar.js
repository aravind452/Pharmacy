import { Link } from "react-router-dom";
import "./AdminNavbar.css";

const AdminNavbar = (props) => {
  return (
    <header className="header">
      <nav>
        <ul>
          <li>
            <Link to="/admin/dashboard">Dashboard</Link>
          </li>
          <li>
            <Link to="/admin/dashboard/add-medicine">Add Medicine</Link>
          </li>
          <li>
            <Link to="/admin/dashboard/update-medicine">Update Medicine</Link>
          </li>
          <li>
            <Link to="/admin/dashboard/delete-medicine">Delete Medicine</Link>
          </li>
          <li>
            <Link to="/admin">Logout</Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default AdminNavbar;
