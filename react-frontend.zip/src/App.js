import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Homepage from "./Pages/Homepage/Homepage";
import RegisterPage from "./Pages/RegisterPage/RegisterPage";
import LoginPage from "./Pages/LoginPage/LoginPage";
import CartPage from "./Pages/CartPage/CartPage";
import AdminLoginPage from "./Pages/AdminLoginPage/AdminLoginPage";
import AdminDashboard from "./Pages/AdminPage/AdminDashboard";
import AddPage from "./Pages/AddPage/AddPage";
import UpdatePage from "./Pages/UpdatePage/UpdatePage";
import DeletePage from "./Pages/DeletePage/DeletePage";
import { ProductsContextProvider } from "./ContextAPI/ProductsContext";
import { UserDetailsContextProvider } from "./ContextAPI/UserDetailsContext";

function App() {
  return (
    <div>
      <UserDetailsContextProvider>
        <ProductsContextProvider>
          <BrowserRouter>
            <Routes>
              <Route exact path="/" element={<LoginPage />} />
              <Route exact path="/home" element={<Homepage />} />
              <Route exact path="/register" element={<RegisterPage />} />
              <Route exact path="/cart" element={<CartPage />} />
              <Route exact path="/admin" element={<AdminLoginPage />} />
              <Route
                exact
                path="/admin/dashboard"
                element={<AdminDashboard />}
              />
              <Route
                exact
                path="/admin/dashboard/add-medicine"
                element={<AddPage />}
              />
              <Route
                exact
                path="/admin/dashboard/update-medicine"
                element={<UpdatePage />}
              />
              <Route
                exact
                path="/admin/dashboard/delete-medicine"
                element={<DeletePage />}
              />
            </Routes>
          </BrowserRouter>
        </ProductsContextProvider>
      </UserDetailsContextProvider>
    </div>
  );
}

export default App;
